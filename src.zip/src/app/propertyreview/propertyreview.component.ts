import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertyreview',
  templateUrl: './propertyreview.component.html',
  styleUrls: ['./propertyreview.component.scss']
})
export class PropertyreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
