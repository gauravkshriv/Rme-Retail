// import { NgModule }   from '@angular/core';
// import { CommonModule }   from '@angular/common';
// import { HttpClientModule } from '@angular/common/http';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { DashboardComponent }  from './dashboard.component';
// import { DashRoutingModule }  from './dash-routing.module';
// import { OwlModule } from 'ngx-owl-carousel';
// import { LightboxModule } from 'ngx-lightbox';
// import { NguCarouselModule } from '@ngu/carousel';
// import { Ng5SliderModule } from 'ng5-slider';
// @NgModule({
//   imports: [     
//         CommonModule,
// 		ReactiveFormsModule,
//         DashRoutingModule,
//         Ng5SliderModule,
//         LightboxModule,
//         NguCarouselModule,
//         OwlModule,
//         FormsModule,ReactiveFormsModule,HttpClientModule
//   ], 
//   declarations: [
//     DashboardComponent
//   ],
//   providers: [],
// })
// export class DashModule { }