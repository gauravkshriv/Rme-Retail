export class TopViewProperty
{
    viewproperties:any;
    uuid:any;
    propertyName:any;
    views:any;
    state:any;
    city:any;
    carpetArea:any;
    superBuiltUpArea:any;
    uploadedBy:any;
    propertyDescription:any;
}