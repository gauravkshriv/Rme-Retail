import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commfilter',
  templateUrl: './commfilter.component.html',
  styleUrls: ['./commfilter.component.scss']
})
export class CommfilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
  