import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agrfilter',
  templateUrl: './agrfilter.component.html',
  styleUrls: ['./agrfilter.component.scss']
})
export class AgrfilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
