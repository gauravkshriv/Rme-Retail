import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indfilter',
  templateUrl: './indfilter.component.html',
  styleUrls: ['./indfilter.component.scss']
})
export class IndfilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
